# -*- coding: utf-8 -*-
#
#Import all needed libraries for this project
import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler 
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor
import matplotlib.pyplot as plt

#Sample datasets are already imported as presented by Xavier_Torres
df = pd.read_csv('sampleData1.csv', sep=";")

#print(X)
#df.head()
#df.corr()
#df.describe()
#df.dtypes

X = df.iloc[:,:4] 
X.head()
X.shape

Y = df.iloc[:,4:]
#print(Y)
Y.head()
Y.shape
# Split train and test
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.3, random_state=45, shuffle=True)
#NeXt Step is to Scale features
#print("Xtrain:",X_train,"Ytrain:",Y_train)
sf = StandardScaler()
X_train = sf.fit_transform(X_train)

X_test = sf.transform(X_test)

#Training the algorithm with the sample dataset
estimatorModel = RandomForestRegressor(n_estimators = 300, random_state = 0)
estimatorModel.fit(X_train, Y_train)
#Model Score
mScore = estimatorModel.score(X_train,Y_train)

#Prediction
Predict_Y = estimatorModel.predict(X_test)

#Evaluating algorithm performance
#MSE Result
print('Mean Squared Error:', metrics.mean_squared_error(Y_test,Predict_Y))
#Variance score: 1 is perfect prediction score
print('Test Variance Score: %.2f' % r2_score(Y_test, Predict_Y))
#Variance score: 1 is perfect prediction score
print("R^2 Prediction Score:",mScore)

#Run the model against the test data presented through a plot
fig, pX = plt.subplots()

pX.scatter(Y_test, Predict_Y, edgecolors=(0, 0, 0))
pX.plot([Y_test.min(), Y_test.max()], [Y_test.min(), Y_test.max()], 'm--', lw=3)
pX.set_xlabel('Actual Data')
pX.set_ylabel('Predicted Data')
pX.set_title("Verified vs Predicted")
plt.show()
